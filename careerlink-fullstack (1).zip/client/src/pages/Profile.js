
import React from 'react';
function Profile() {
  return <div>Profile Page</div>;
}
export default Profile;
